/*
 * This files holds all the code to for your card game
 */

//Run once broswer has loaded everything
window.onload = async function () {

    function addUpPlayerScore()
    {
        for (var i = 0; i < myJson2.cards.length; i++)
        {
            if(myJson2.cards[i].value == "KING" || myJson2.cards[i].value == "QUEEN" || myJson2.cards[i].value == "JACK")
            {
                playerScore +=10;
                
            } else if (myJson2.cards[i].value == "ACE")
            {
                playerScore += 11; //or 1
            } else //else convert value to int
            {
                playerScore += parseInt(myJson2.cards[i].value)
            }
        }
    }

    function addUpDealerScore()
    {
        dealerScore = 0
        for (var i = 0; i < myJson.cards.length; i++)
        {
            if(myJson.cards[i].value == "KING" || myJson.cards[i].value == "QUEEN" || myJson.cards[i].value == "JACK")
            {
                dealerScore +=10;
                
            } else if (myJson.cards[i].value == "ACE")
            {
                dealerScore += 11; //or 1
            } else //else convert value to int
            {
                dealerScore += parseInt(myJson.cards[i].value)
            }
        }
        document.getElementById('dScore').innerHTML = "Dealer Score: " + dealerScore;


    }

    function hitAddScore()
    {
        if(myJson2.cards[0].value == "KING" || myJson2.cards[0].value == "QUEEN" || myJson2.cards[0].value == "JACK")
            {
                playerScore +=10;
                
            } else if (myJson2.cards[0].value == "ACE")
            {
                playerScore += 11; //or 1
            } else //else convert value to int  
            {
                playerScore += parseInt(myJson2.cards[0].value)
            }
        document.getElementById('pScore').innerHTML = "Player Score: " + playerScore;
        numCardsPlayer++
        var newCard = 'pHand' + numCardsPlayer
        document.getElementById(newCard).src = myJson2.cards[0].image;
    }

    function hitAddScoreDealer()
    {
        if(myJson.cards[0].value == "KING" || myJson.cards[0].value == "QUEEN" || myJson.cards[0].value == "JACK")
            {
                dealerScore +=10;
                
            } else if (myJson.cards[0].value == "ACE")
            {
                dealerScore += 11; //or 1
            } else //else convert value to int
            {
                dealerScore += parseInt(myJson.cards[0].value)
            }
        document.getElementById('dScore').innerHTML = "Dealer Score: " + dealerScore;
        numCardsDealer++
        var newCard = 'dHand' + numCardsDealer
        document.getElementById(newCard).src = myJson.cards[0].image;
    }

    

    async function endGameWin()
    {
        console.log("game over")
        $('#gameOverWinModal')
            .modal('show')
        ;
        $('#restart').click(async function()
        {
        resetGame()
        })
    }

    async function endGameLoss()
    {
        console.log("game over")
        $('#gameOverLossModal')
            .modal('show')
        ;
        $('#restart').click(async function()
        {
        resetGame()
        })
    }

    async function endGameTie()
    {
        console.log("game over")
        $('#gameOverTieModal')
            .modal('show')
        ;
        $('#restart').click(async function()
        {
        resetGame()
        })
    }

    async function resetGame()
    {
        console.log("reset game")
        numCardsDealer = 0
        numCardsPlayer = 0

        var url = await fetch('https://deckofcardsapi.com/api/deck/new/draw/?count=2');
        var numCardsDealer = 2
           
        //create a JSON from the results    
        var myJson = await url.json();
    
        var dealerScore = 0
        var playerScore = 0
        //myJson.cards
        if(myJson.cards[1].value == "KING" || myJson.cards[1].value == "QUEEN" || myJson.cards[1].value == "JACK")
        {
            dealerScore +=10;
            
        } else if (myJson.cards[1].value == "ACE")
        {
            dealerScore += 11; //or 1
        } else //else convert value to int
        {
            dealerScore += parseInt(myJson.cards[1].value)
        }    
        
        //draw 2 cards for the player
        var url2 = await fetch('https://deckofcardsapi.com/api/deck/' + myJson.deck_id + '/draw/?count=2');
        var numCardsPlayer = 2
        var myJson2 = await url2.json();
    
        addUpPlayerScore();

        console.log("reset game")
        displayDealerCards();
    }

    async function displayDealerCards()
    {

    //document.getElementById('dScore').innerHTML = "Dealer Score: " + dealerScore;
    document.getElementById('dHand1').src = "https://i.pinimg.com/originals/10/80/a4/1080a4bd1a33cec92019fab5efb3995d.png"
    document.getElementById('dHand1').width = 226
    document.getElementById('dHand1').height = 314
    document.getElementById('dHand2').src = "https://i.pinimg.com/originals/10/80/a4/1080a4bd1a33cec92019fab5efb3995d.png"
    document.getElementById('dHand2').width = 226
    document.getElementById('dHand2').height = 314    

    $('#dHand1')
        .transition({
            animation: 'slide down',
            duration: '2s',
            /*onComplete: function() {
                $('#dHand1')
                    .transition('slide down')
                ;
            }*/
    })  

    $('#dHand2')
        .transition({
            animation: 'slide down',
            duration: '2s',
            onComplete: function() {
            //    $('#dHand2')
              //      .transition('slide down')
                //;
                document.getElementById('dScore').innerHTML = "Dealer Score: " + dealerScore;
            }
    })  
        
        
    $('#dHand2')
        .transition({
            animation: 'horizontal flip',
            duration: '2s',
            onComplete: function() {
                document.getElementById('dHand2').src = myJson.cards[1].image;
                $('#dHand2')
                    .transition('horizontal flip')
                ;
                displayPlayerCards();
                //alert('done')
            }
        });    
    }

    async function displayPlayerCards()
    {
    //document.getElementById('pScore').innerHTML = "Player Score: " + playerScore;
    document.getElementById('pHand1').src = "https://i.pinimg.com/originals/10/80/a4/1080a4bd1a33cec92019fab5efb3995d.png"
    document.getElementById('pHand1').width = 226
    document.getElementById('pHand1').height = 314
    document.getElementById('pHand2').src = "https://i.pinimg.com/originals/10/80/a4/1080a4bd1a33cec92019fab5efb3995d.png";
    document.getElementById('pHand2').width = 226
    document.getElementById('pHand2').height = 314

    $('#pHand1')
        .transition({
            animation: 'slide down',
            duration: '2s',
            /*onComplete: function() {
                $('#dHand1')
                    .transition('slide down')
                ;
            }*/
    })  

    $('#pHand2')
        .transition({
            animation: 'slide down',
            duration: '2s',
            onComplete: function() {
            //    $('#dHand2')
              //      .transition('slide down')
                //;
                document.getElementById('pScore').innerHTML = "Player Score: " + playerScore;
            }
    })  
           
    $('#pHand1')
        .transition({
            animation: 'horizontal flip',
            duration: '2s',
            onComplete: function() {
                document.getElementById('pHand1').src = myJson2.cards[0].image;
                $('#pHand1')
                    .transition('horizontal flip')
                ;
                //alert('done')
            }
        }); 

    $('#pHand2')
        .transition({
            animation: 'horizontal flip',
            duration: '2s',
            onComplete: function() {
                document.getElementById('pHand2').src = myJson2.cards[1].image;
                $('#pHand2')
                    .transition('horizontal flip')
                ;
                //alert('done')
            }
        });  

    }


    document.body.style.backgroundColor = "green";
    $('#dHand1')
        .transition('slide down')
    ;
    $('#dHand2')
        .transition('slide down')
    ;

    $('#pHand1')
        .transition('slide down')
    ;
    $('#pHand2')
        .transition('slide down')
    ;


    //$('.ui.modal')
    $('#introModal')
      .modal('show')
    ;



    //draw 2 cards for dealer
    var url = await fetch('https://deckofcardsapi.com/api/deck/new/draw/?count=2');
    var numCardsDealer = 2
           
    //create a JSON from the results    
    var myJson = await url.json();

    var dealerScore = 0
    var playerScore = 0
    if(myJson.cards[1].value == "KING" || myJson.cards[1].value == "QUEEN" || myJson.cards[1].value == "JACK")
    {
        dealerScore +=10;
        
    } else if (myJson.cards[1].value == "ACE")
    {
        dealerScore += 11; //or 1
    } else //else convert value to int
    {
        dealerScore += parseInt(myJson.cards[1].value)
    }

    $('#deal').click(async function()
    {
        displayDealerCards();
    })
    console.log(myJson)

    //draw 2 cards for the player
    var url2 = await fetch('https://deckofcardsapi.com/api/deck/' + myJson.deck_id + '/draw/?count=2');
    var numCardsPlayer = 2
    var myJson2 = await url2.json();

    addUpPlayerScore();

    $('#hitme').click(async function()
    {
        url2 = await fetch('https://deckofcardsapi.com/api/deck/' + myJson.deck_id + '/draw/?count=1');
        myJson2 = await url2.json();
        hitAddScore();
        if (playerScore > 21)
        {
            console.log("bust")
            endGameLoss()
        }
    })

    $('#stay').click(async function()
    {
        //flip card and update score
        document.getElementById('dHand1').src = myJson.cards[0].image;
        addUpDealerScore();

        if (dealerScore > playerScore)
        {
            endGameLoss();
        }

        if (dealerScore < 17 && (dealerScore < playerScore))
        {
            url = await fetch('https://deckofcardsapi.com/api/deck/' + myJson.deck_id + '/draw/?count=1');
            myJson = await url.json();
            hitAddScoreDealer();
        } 

        while (dealerScore < 17 && (dealerScore < playerScore))
        {
            url = await fetch('https://deckofcardsapi.com/api/deck/' + myJson.deck_id + '/draw/?count=1');
            myJson = await url.json();
            hitAddScoreDealer();
        }
        if (playerScore > dealerScore || dealerScore > 21)
        {
            endGameWin();
            console.log("you win!")
        } else if (playerScore == dealerScore)
        {
            endGameTie();
        } else {
            endGameLoss();
            console.log("you lose")
        }

    })

    $('#restart').click(async function()
    {
        resetGame()
    })

//All your Front end code should be here!

};
